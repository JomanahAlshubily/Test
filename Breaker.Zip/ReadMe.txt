Breaker Game

1. open the NetBeans program
2. click on File
3. click on lmport project
4. click on From ZIP
5. choose our project from the brows button
6. click right on porject name 
7. click on Run
8. The Game will appear 
9. Now, you can start playing by using the arrow keys to move the paddle 
10. Everytime the ball hits the rectangle, your score will increase

when you hit all the rectangkes, you win 
By click Enter key you can restart and enjoy more and more